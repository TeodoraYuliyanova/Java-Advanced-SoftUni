package ListUtilities;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Integer> numbers = List.of(13, 42, 69, 73);

        System.out.println(ListUtil.getMin(numbers));
        System.out.println(ListUtil.getMax(numbers));

        List<String> strings = List.of("a" , "b" ,  "c");
        System.out.println(ListUtil.getMax(strings));
        System.out.println(ListUtil.getMin(strings));
    }
}
